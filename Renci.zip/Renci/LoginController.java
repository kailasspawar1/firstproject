import ticketing.Ticket;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String un=request.getParameter("username");
		String pw=request.getParameter("password");
		
		Ticket obj1=new Ticket();
		
		if(un.equals("admin") && pw.equals("admin"))
		{
			
		    String ticket=	obj1.getTicket("codata","codata");
		    String URL="https://qliksence/renci/hub?qlikTicket="+ticket;
			response.sendRedirect(URL);
			return;
		}
		else
		{
			response.sendRedirect("error.html");
			return;
		}
	}
}